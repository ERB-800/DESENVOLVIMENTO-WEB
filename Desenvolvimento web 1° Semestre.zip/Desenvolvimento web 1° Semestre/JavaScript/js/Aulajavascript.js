
var variavel = 10;
alert(variavel);

//Númericas
var numInt = 5 //integer
var numFlo = 10.5 //Float

//Alfanúmericas
var textoCha = "a"
var textoStr = "Texto longo"

//Booleanas
var logicoBoo = false

//Indefinidas
var nulasNul = null
var indefinida

console.log(numInt)
console.log(numFlo)
console.log(textoCha)
console.log(textoStr)
console.log(logicoBoo)
console.log(nulasNul)
console.log(indefinida)

var nome = prompt("Digite seu nome: ")
var idade = prompt("Digite sua idade: ")
var open_h2 = "<h2>"
var close_h2 = "</h2>"
document.write(open_h2+"Nome: "+nome+close_h2)
document.write(open_h2+"Idade: "+idade+close_h2)

var num1 = prompt("Número 1")
var num2 = prompt("Número 2")


num1 = parseInt(num1)
num2 = parseInt(num2)
//exibir os número em ordem crescente

if (num1 > num2){
    aux = num1
    num1 = num2
    num2 = aux
}


document.write(num1)
document.write("<br>")
document.write(num2)
